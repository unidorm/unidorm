import { RoommatesScene } from "../../components/illustrations/Illustrations";
import PageHeader from "../../components/layout/PageHeader";
import { ButtonLink, Card, Pill, ProgressBar, StatCard, Stepper } from "../../components/ui";
import { ROUTES } from "../../config/routes";
import {
  accommodationStages,
  currentStageIndex,
  studentOverview,
  surveyStatus,
} from "../../data/student";

export default function StudentHomePage() {
  const overview = studentOverview;
  const stage = accommodationStages[currentStageIndex];

  return (
    <>
      <PageHeader
        eyebrow={`Academic year ${overview.academicYear}`}
        title={`${overview.greeting}, ${overview.firstName}`}
        description="Here is where your room and roommate matching stand right now."
        sampleData
      />

      <div className="grid gap-4 md:grid-cols-3">
        <StatCard
          label="Accommodation application"
          value={overview.building}
          footer={<Pill tone={overview.applicationStatus.tone}>{overview.applicationStatus.label}</Pill>}
        />
        <StatCard
          label="Room type"
          value={overview.roomType.value}
          footer={<Pill tone={overview.roomType.status.tone}>{overview.roomType.status.label}</Pill>}
        />
        <StatCard
          label="Roommate agreement"
          value={overview.agreement.value}
          footer={<Pill tone={overview.agreement.status.tone}>{overview.agreement.status.label}</Pill>}
        />
      </div>

      <Card variant="raised" padding="lg" className="mt-6">
        <div className="grid items-center gap-6 md:grid-cols-[minmax(0,1fr)_minmax(0,20rem)]">
          <div className="min-w-0">
            <p className="eyebrow mb-3">New in UniDorm</p>
            <h2 className="font-display text-2xl font-extrabold leading-tight sm:text-3xl">
              Find a roommate who lives like you
            </h2>
            <p className="mt-3 max-w-xl text-base leading-relaxed text-muted">
              Asking for a shared room? Tell us how you sleep, study and spend your evenings in{" "}
              {surveyStatus.total} quick questions. The housing manager uses your answers to put people who get
              along in the same room.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-3">
              <ButtonLink to={ROUTES.student.accommodation}>Choose room type</ButtonLink>
              <p className="text-sm text-muted">About {overview.surveyMinutes} minutes · KK / RU / EN</p>
            </div>
          </div>
          <RoommatesScene className="mx-auto w-full max-w-xs md:max-w-none" />
        </div>
      </Card>

      <Card
        className="mt-6"
        title="Your progress"
        description={`Stage ${currentStageIndex + 1} of ${accommodationStages.length} · ${stage.label}`}
      >
        <Stepper steps={accommodationStages} currentIndex={currentStageIndex} />
        <ProgressBar
          className="mt-6"
          label="Habits survey"
          valueLabel={`${surveyStatus.answered} of ${surveyStatus.total} questions`}
          value={surveyStatus.answered}
          max={surveyStatus.total}
        />
      </Card>
    </>
  );
}
