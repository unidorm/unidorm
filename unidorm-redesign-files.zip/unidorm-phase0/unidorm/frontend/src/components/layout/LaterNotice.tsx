import { Hourglass } from "../illustrations/Illustrations";

export interface LaterNoticeProps {
  children: string;
}

/** Banner for sections marked "later" in the prototype, so they never look finished. */
export default function LaterNotice({ children }: LaterNoticeProps) {
  return (
    <div role="note" className="mb-6 flex items-center gap-4 rounded-card bg-warning/10 px-5 py-4">
      <Hourglass className="size-10 shrink-0" />
      <p className="min-w-0 flex-1 text-sm leading-relaxed text-muted">
        <span className="font-bold text-text">Coming in a later sprint. </span>
        {children}
      </p>
    </div>
  );
}
