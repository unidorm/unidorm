import type { SVGProps } from "react";

/**
 * Hand-drawn style illustrations for UniDorm (original artwork, inline SVG, no image files).
 * Thick rounded outlines + flat colours. They are decorative, so they are hidden from screen readers.
 */
const C = {
  ink: "#23324D",
  sky: "#2F6BD8",
  skyLight: "#DCE8FB",
  sun: "#FFC94D",
  mint: "#8EDCC0",
  coral: "#FF8F7E",
  lilac: "#C9B8F5",
  skinLight: "#F6C9A8",
  skinDark: "#C98E6B",
  box: "#F3D9A4",
  white: "#FFFFFF",
};

type Props = Omit<SVGProps<SVGSVGElement>, "viewBox">;

const line = { stroke: C.ink, strokeWidth: 2.5, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };

function Svg({ viewBox, children, ...rest }: Props & { viewBox: string }) {
  return (
    <svg viewBox={viewBox} fill="none" aria-hidden="true" focusable="false" {...rest}>
      {children}
    </svg>
  );
}

function Sparkle({ x, y, size = 6, color = C.sun }: { x: number; y: number; size?: number; color?: string }) {
  return (
    <path
      d={`M${x} ${y - size} Q${x} ${y} ${x + size} ${y} Q${x} ${y} ${x} ${y + size} Q${x} ${y} ${x - size} ${y} Q${x} ${y} ${x} ${y - size}Z`}
      fill={color}
      stroke={C.ink}
      strokeWidth={1.5}
      strokeLinejoin="round"
    />
  );
}

/** Two roommates in front of a window: the home page picture. */
export function RoommatesScene(props: Props) {
  return (
    <Svg viewBox="0 0 320 200" {...props}>
      {/* window with a moon */}
      <rect x="122" y="18" width="76" height="62" rx="12" fill={C.skyLight} {...line} />
      <circle cx="172" cy="40" r="10" fill={C.sun} />
      <circle cx="177" cy="36" r="9" fill={C.skyLight} />
      <path d="M160 18v62M122 49h76" {...line} />
      <Sparkle x={140} y={32} size={4} color={C.white} />

      {/* floor */}
      <path d="M14 182h292" {...line} />

      {/* left roommate */}
      <rect x="40" y="98" width="70" height="84" rx="35" fill={C.coral} {...line} />
      <path d="M48 128q-14 10-8 26" {...line} />
      <circle cx="75" cy="80" r="26" fill={C.skinLight} {...line} />
      <path d="M49 77q2-25 26-25t26 25q-9-12-26-11-16 0-26 11z" fill={C.ink} />
      <circle cx="67" cy="80" r="2.6" fill={C.ink} />
      <circle cx="83" cy="80" r="2.6" fill={C.ink} />
      <path d="M68 89q7 6 14 0" {...line} />
      <circle cx="61" cy="88" r="3.5" fill={C.coral} opacity="0.55" />
      <circle cx="89" cy="88" r="3.5" fill={C.coral} opacity="0.55" />

      {/* right roommate */}
      <rect x="210" y="98" width="70" height="84" rx="35" fill={C.mint} {...line} />
      <path d="M270 130q10 8 6 24" {...line} />
      <circle cx="245" cy="80" r="26" fill={C.skinDark} {...line} />
      <circle cx="245" cy="50" r="10" fill={C.ink} />
      <path d="M220 76q4-20 25-20t25 20q-11-9-25-9t-25 9z" fill={C.ink} />
      <circle cx="237" cy="80" r="2.6" fill={C.ink} />
      <circle cx="253" cy="80" r="2.6" fill={C.ink} />
      <path d="M238 89q7 6 14 0" {...line} />

      {/* heart between them */}
      <path
        d="M160 128c-12-10-14-20-6-23 4-1 6 2 6 4 0-2 2-5 6-4 8 3 6 13-6 23z"
        fill={C.coral}
        {...line}
        strokeWidth={2}
      />
      <Sparkle x={130} y={112} />
      <Sparkle x={192} y={104} size={5} color={C.lilac} />

      {/* small plant */}
      <path d="M302 182v-14h-18v14" fill={C.sun} {...line} />
      <path d="M293 168q-2-14 8-18M293 168q-4-10-10-12" {...line} />
    </Svg>
  );
}

/** Clipboard with ticks: the survey picture. */
export function SurveyClipboard(props: Props) {
  return (
    <Svg viewBox="0 0 140 140" {...props}>
      <rect x="28" y="22" width="78" height="100" rx="12" fill={C.white} {...line} />
      <rect x="50" y="14" width="34" height="16" rx="6" fill={C.sun} {...line} />
      {[48, 72, 96].map((y, i) => (
        <g key={y}>
          <rect x="40" y={y - 7} width="14" height="14" rx="4" fill={i < 2 ? C.mint : C.white} {...line} strokeWidth={2} />
          {i < 2 && <path d={`M43 ${y}l3 3 5-6`} {...line} strokeWidth={2} />}
          <path d={`M62 ${y}h${i === 1 ? 22 : 30}`} {...line} strokeWidth={2} />
        </g>
      ))}
      {/* pencil */}
      <path d="M100 118l22-34 8 5-22 34-10 4z" fill={C.coral} {...line} strokeWidth={2} />
      <path d="M118 90l8 5" {...line} strokeWidth={2} />
      <Sparkle x={120} y={30} size={6} />
    </Svg>
  );
}

/** A box with a face: empty lists. */
export function EmptyBox(props: Props) {
  return (
    <Svg viewBox="0 0 160 120" {...props}>
      <path d="M20 108h120" {...line} />
      <path d="M35 50l-12-16h58l-1 16" fill={C.box} {...line} />
      <path d="M125 50l12-16H79l1 16" fill={C.box} {...line} />
      <rect x="35" y="50" width="90" height="56" rx="8" fill={C.box} {...line} />
      <circle cx="66" cy="76" r="3" fill={C.ink} />
      <circle cx="94" cy="76" r="3" fill={C.ink} />
      <ellipse cx="80" cy="88" rx="4" ry="3.2" fill={C.ink} />
      <Sparkle x={30} y={22} size={5} />
      <Sparkle x={136} y={16} size={4} color={C.lilac} />
    </Svg>
  );
}

/** A confused door: page not found. */
export function LostDoor(props: Props) {
  return (
    <Svg viewBox="0 0 180 170" {...props}>
      <path d="M20 152h140" {...line} />
      <rect x="55" y="28" width="70" height="124" rx="12" fill={C.skyLight} {...line} />
      <circle cx="112" cy="96" r="4" fill={C.sun} {...line} strokeWidth={2} />
      <circle cx="78" cy="70" r="3" fill={C.ink} />
      <circle cx="100" cy="70" r="3" fill={C.ink} />
      <path d="M78 86q5-4 11 0t11 0" {...line} />
      {/* question mark */}
      <path d="M140 30q0-12 12-12t12 11q0 8-10 12v6" {...line} strokeWidth={3} />
      <circle cx="154" cy="56" r="2.5" fill={C.ink} />
      <Sparkle x={34} y={40} size={6} color={C.coral} />
    </Svg>
  );
}

/** Small hourglass for "coming later" notes. */
export function Hourglass(props: Props) {
  return (
    <Svg viewBox="0 0 40 40" {...props}>
      <path d="M11 6h18M11 34h18" {...line} />
      <path d="M13 6c0 8 14 10 14 14s-14 6-14 14h14c0-8-14-10-14-14s14-6 14-14z" fill={C.white} {...line} strokeWidth={2} />
      <path d="M16 31q4-5 8 0z" fill={C.sun} />
      <path d="M17 12h6l-3 4z" fill={C.sun} />
    </Svg>
  );
}

/** Logo: a small house with a lit window. */
export function HouseMark(props: Props) {
  return (
    <Svg viewBox="0 0 40 40" {...props}>
      <path d="M8 19 20 9l12 10v12a2 2 0 0 1-2 2H10a2 2 0 0 1-2-2z" fill={C.white} stroke={C.white} strokeWidth={2} strokeLinejoin="round" />
      <rect x="16.5" y="21" width="7" height="7" rx="1.5" fill={C.sun} />
    </Svg>
  );
}

/** Row of little beds, one per person, for the room type options. */
export function Beds({ count, ...props }: Props & { count: number }) {
  const width = count * 32 + 4;
  return (
    <Svg viewBox={`0 0 ${width} 34`} height={34} width={width} {...props}>
      {Array.from({ length: count }, (_, i) => {
        const x = 4 + i * 32;
        return (
          <g key={i}>
            <rect x={x} y="6" width="6" height="24" rx="2" fill={C.sky} {...line} strokeWidth={2} />
            <rect x={x} y="16" width="26" height="12" rx="4" fill={C.skyLight} {...line} strokeWidth={2} />
            <rect x={x + 8} y="11" width="9" height="6" rx="2.5" fill={C.white} {...line} strokeWidth={1.75} />
          </g>
        );
      })}
    </Svg>
  );
}

/** Doodle for each survey area. */
export function CategoryDoodle({ category, ...props }: Props & { category: "sleep" | "noise" | "cleanliness" | "visitors" | "study" }) {
  const art = {
    sleep: (
      <>
        <path d="M30 10a14 14 0 1 0 8 24A16 16 0 0 1 30 10z" fill={C.sun} {...line} strokeWidth={2} />
        <Sparkle x={36} y={14} size={3.5} color={C.white} />
      </>
    ),
    noise: (
      <>
        <path d="M12 28v-4a12 12 0 0 1 24 0v4" {...line} strokeWidth={2} />
        <rect x="8" y="26" width="9" height="13" rx="4" fill={C.coral} {...line} strokeWidth={2} />
        <rect x="31" y="26" width="9" height="13" rx="4" fill={C.coral} {...line} strokeWidth={2} />
      </>
    ),
    cleanliness: (
      <>
        <circle cx="18" cy="28" r="9" fill={C.mint} {...line} strokeWidth={2} />
        <circle cx="32" cy="20" r="6" fill={C.white} {...line} strokeWidth={2} />
        <circle cx="31" cy="34" r="4" fill={C.mint} {...line} strokeWidth={2} />
        <Sparkle x={14} y={12} size={4} />
      </>
    ),
    visitors: (
      <>
        <rect x="13" y="8" width="22" height="32" rx="5" fill={C.lilac} {...line} strokeWidth={2} />
        <circle cx="29" cy="25" r="2" fill={C.ink} />
        <path d="M8 40h32" {...line} strokeWidth={2} />
      </>
    ),
    study: (
      <>
        <path d="M24 14q-8-5-17-3v24q9-2 17 3z" fill={C.skyLight} {...line} strokeWidth={2} />
        <path d="M24 14q8-5 17-3v24q-9-2-17 3z" fill={C.white} {...line} strokeWidth={2} />
        <path d="M28 19q4-1.5 9-1M28 25q4-1.5 9-1" {...line} strokeWidth={1.75} />
      </>
    ),
  }[category];
  return (
    <Svg viewBox="0 0 48 48" {...props}>
      {art}
    </Svg>
  );
}
